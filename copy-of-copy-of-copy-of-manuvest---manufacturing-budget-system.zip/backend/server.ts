import express from 'express';
import cors from 'cors';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// --- Helper: Parse JSON fields for response ---
const parseProject = (p: any) => ({
  ...p,
  schedule: p.schedule ? JSON.parse(p.schedule) : {},
  customMilestones: p.customMilestones ? JSON.parse(p.customMilestones) : []
});

const parseBudget = (b: any) => ({
  ...b,
  items: b.items.map((i: any) => ({
    ...i,
    transfers: i.transfers ? JSON.parse(i.transfers) : []
  }))
});

const parsePR = (pr: any) => ({
  ...pr,
  history: pr.history ? JSON.parse(pr.history) : []
});

// --- ROUTES ---

// 1. Auth (Simple Mock)
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await prisma.user.findUnique({ where: { username } });
  
  if (user && user.password === password) {
    const { password, ...userWithoutPass } = user;
    res.json(userWithoutPass);
  } else {
    res.status(401).json({ error: "Invalid credentials" });
  }
});

// 2. Master Data (Get All)
app.get('/api/master-data', async (req, res) => {
  try {
    const [departments, categories, ios, costCenters, projects, plants, suppliers, currencies, items] = await Promise.all([
      prisma.department.findMany(),
      prisma.businessCategory.findMany(),
      prisma.iONumber.findMany(),
      prisma.costCenter.findMany(),
      prisma.project.findMany(),
      prisma.plant.findMany(),
      prisma.supplier.findMany(),
      prisma.currency.findMany(),
      prisma.masterItem.findMany()
    ]);

    res.json({
      departments,
      categories,
      ios,
      costCenters,
      projects: projects.map(parseProject),
      plants,
      suppliers,
      currencies,
      items
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch master data" });
  }
});

// 3. Projects
app.get('/api/projects', async (req, res) => {
  const projects = await prisma.project.findMany();
  res.json(projects.map(parseProject));
});

app.post('/api/projects', async (req, res) => {
  const { schedule, customMilestones, ...data } = req.body;
  const project = await prisma.project.create({
    data: {
      ...data,
      schedule: JSON.stringify(schedule),
      customMilestones: JSON.stringify(customMilestones)
    }
  });
  res.json(parseProject(project));
});

app.put('/api/projects/:id', async (req, res) => {
  const { id } = req.params;
  const { schedule, customMilestones, ...data } = req.body;
  const project = await prisma.project.update({
    where: { id },
    data: {
      ...data,
      schedule: JSON.stringify(schedule),
      customMilestones: JSON.stringify(customMilestones)
    }
  });
  res.json(parseProject(project));
});

app.delete('/api/projects/:id', async (req, res) => {
  await prisma.project.delete({ where: { id: req.params.id } });
  res.json({ success: true });
});

// 4. Budgets
app.get('/api/budgets', async (req, res) => {
  const budgets = await prisma.budgetPlan.findMany({
    include: { items: true }
  });
  res.json(budgets.map(parseBudget));
});

app.post('/api/budgets', async (req, res) => {
  const { items, ...header } = req.body;
  
  const budget = await prisma.budgetPlan.create({
    data: {
      ...header,
      items: {
        create: items.map((i: any) => ({
            ...i,
            transfers: JSON.stringify(i.transfers || [])
        }))
      }
    },
    include: { items: true }
  });
  res.json(parseBudget(budget));
});

app.put('/api/budgets/:id', async (req, res) => {
  const { id } = req.params;
  const { items, ...header } = req.body;

  // Transaction: Delete existing items, Update header, Create new items
  // (Simplification for MVP: Full replace strategy)
  const op = await prisma.$transaction([
    prisma.budgetPlanItem.deleteMany({ where: { budgetPlanId: id } }),
    prisma.budgetPlan.update({
      where: { id },
      data: {
        ...header,
        items: {
            create: items.map((i: any) => ({
                ...i,
                transfers: JSON.stringify(i.transfers || [])
            }))
        }
      },
      include: { items: true }
    })
  ]);
  
  // The second op result is the updated budget
  res.json(parseBudget(op[1]));
});

app.delete('/api/budgets/:id', async (req, res) => {
  await prisma.budgetPlan.delete({ where: { id: req.params.id } });
  res.json({ success: true });
});

// 5. Purchase Requests
app.get('/api/prs', async (req, res) => {
  const prs = await prisma.purchaseRequest.findMany({
    include: { items: true }
  });
  res.json(prs.map(parsePR));
});

app.post('/api/prs', async (req, res) => {
  const { items, history, ...header } = req.body;
  const pr = await prisma.purchaseRequest.create({
    data: {
      ...header,
      history: JSON.stringify(history || []),
      items: { create: items }
    },
    include: { items: true }
  });
  res.json(parsePR(pr));
});

app.put('/api/prs/:id', async (req, res) => {
  const { id } = req.params;
  const { items, history, ...header } = req.body;

  const op = await prisma.$transaction([
    prisma.pRItem.deleteMany({ where: { purchaseRequestId: id } }),
    prisma.purchaseRequest.update({
        where: { id },
        data: {
            ...header,
            history: JSON.stringify(history || []),
            items: { create: items }
        },
        include: { items: true }
    })
  ]);
  res.json(parsePR(op[1]));
});

// Start Server
app.listen(PORT, () => {
  console.log(`ManuVest Backend running on http://localhost:${PORT}`);
});
