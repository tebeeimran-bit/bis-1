import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  // Users
  await prisma.user.createMany({
    data: [
      { username: 'admin', password: '123', name: 'Admin Administrator', role: 'Admin', department: 'IT' },
      { username: 'user', password: '123', name: 'John Engineer', role: 'User', department: 'Engineering' },
      { username: 'approver', password: '123', name: 'Sarah Manager', role: 'Approver', department: 'Management' }
    ]
  });

  // Master Data
  await prisma.department.createMany({
    data: [
        { code: 'ENG', name: 'Engineering' },
        { code: 'PROD', name: 'Production' },
        { code: 'QA', name: 'Quality Assurance' }
    ]
  });
  
  await prisma.businessCategory.createMany({
    data: [
        { code: 'WH', name: 'Wiring Harness' },
        { code: 'AEP', name: 'Automotive Electronics' }
    ]
  });

  await prisma.iONumber.createMany({
    data: [
        { code: 'IO-1001', name: 'New Machine Inv' },
        { code: 'IO-2001', name: 'R&D Tools' }
    ]
  });
  
  await prisma.costCenter.createMany({
    data: [
        { code: 'CC-501', name: 'Plant A - Assy' },
        { code: 'CC-502', name: 'Plant B - Molding' }
    ]
  });

  console.log("Seeding completed.");
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    (process as any).exit(1);
  });